package com.ohmycar.domain;

public class CarVO {
	private String userId;
	private String carId;
	private String carSellName;
	private String carName;
	private String carType;

	// 생성자, Getter 및 Setter 메서드 생략

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCarId() {
		return carId;
	}

	public void setCarId(String carId) {
		this.carId = carId;
	}

	public String getCarSellName() {
		return carSellName;
	}

	public void setCarSellName(String carSellName) {
		this.carSellName = carSellName;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}
}
